package kr.spring.entity;

public enum Role {
	ADMIN, MANAGER, MEMBER;
}
