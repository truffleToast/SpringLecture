SELECT * FROM BOARD;


INSERT INTO BOARD(TITLE, CONTENT, WRITER) 
VALUES('버스버스', '버스버스', '버스');
INSERT INTO BOARD(TITLE, CONTENT, WRITER) 

VALUES('오늘 저녁에 하늘마당에서 보실 분', '내가 치킨 쏜다', '명훈');
INSERT INTO BOARD(TITLE, CONTENT, WRITER) 

VALUES('이이이이이이이', '어어어어어어어', '히');

INSERT INTO BOARD(TITLE, CONTENT, WRITER) 
VALUES('나나나나', '너너너너', '노노노노노');

INSERT INTO BOARD(TITLE, CONTENT, WRITER) 
VALUES('가가각가가가', '기기기기긱기', '구구구국구');

INSERT INTO BOARD(TITLE, CONTENT, WRITER) 
VALUES('오늘 저녁에 하늘마당에서 보실 분', '나도 치킨 쏜다', '준용');

INSERT INTO BOARD(TITLE, CONTENT, WRITER)
VALUES('여러분 기획서는 쓰셧나요', '안썻으면 내일 쓰세요', '병관');
